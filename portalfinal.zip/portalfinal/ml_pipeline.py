import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder

class InternshipMatcher:
    def __init__(self):
        self.df = pd.read_csv('internships.csv')
        # Clean and preprocess data
        # Clean and preprocess data - convert to string and handle NaN values
        self.df['skills'] = self.df['skills'].astype(str).fillna('')
        self.df['description'] = self.df['description'].astype(str).fillna('')
        self.df['qualification'] = self.df['qualification'].astype(str).fillna('')
        
        self.location_model = NearestNeighbors(n_neighbors=5, metric='cosine')
        self.skills_vectorizer = TfidfVectorizer()
        self.description_vectorizer = TfidfVectorizer()
        self.label_encoder = LabelEncoder()
        self.rf_classifier = RandomForestClassifier()
        self.dt_classifier = DecisionTreeClassifier()
        self.svm_classifier = SVC(probability=True)
        self.fit_models()
    
    def fit_models(self):
        # Fit location model
        locations = pd.get_dummies(self.df['location'])
        self.location_model.fit(locations)
        
        # Fit skills model
        skills_matrix = self.skills_vectorizer.fit_transform(self.df['skills'])
        desc_matrix = self.description_vectorizer.fit_transform(self.df['description'])
        
        # Encode qualifications
        self.encoded_quals = self.label_encoder.fit_transform(self.df['qualification'])
        
        # Combine features for classification
        combined_features = np.hstack([
            skills_matrix.toarray(),
            desc_matrix.toarray(),
            self.encoded_quals.reshape(-1, 1)
        ])
        
        # Fit classifiers
        self.rf_classifier.fit(combined_features, self.encoded_quals)
        self.dt_classifier.fit(combined_features, self.encoded_quals)
        self.svm_classifier.fit(combined_features, self.encoded_quals)
    
    def preprocess_resume(self, resume_text):
        # Extract skills and qualifications from resume
        # This is a simple implementation - can be enhanced with more sophisticated NLP
        skills_text = resume_text  # In real implementation, extract skills
        return skills_text
    
    def match_internships(self, resume_text, preferred_location):
        processed_resume = self.preprocess_resume(resume_text)
        
        # Location matching using KNN
        if preferred_location != 'Any':
            location_vector = pd.get_dummies([preferred_location])
            location_vector = location_vector.reindex(columns=pd.get_dummies(self.df['location']).columns, fill_value=0)
            _, location_indices = self.location_model.kneighbors(location_vector)
            location_indices = location_indices[0].astype(int)  # Ensure integer indices
        else:
            location_indices = np.arange(len(self.df), dtype=int)
        
        # Skills and description matching using NLP
        resume_skills_vector = self.skills_vectorizer.transform([processed_resume]).toarray()
        resume_desc_vector = self.description_vectorizer.transform([processed_resume]).toarray()
        
        # Combine features with proper shape handling
        resume_features = np.hstack([
            resume_skills_vector,
            resume_desc_vector,
            np.zeros((1, 1), dtype=int)  # Placeholder for qualification
        ])
        
        # Get predictions from all classifiers
        rf_proba = self.rf_classifier.predict_proba(resume_features)
        dt_proba = self.dt_classifier.predict_proba(resume_features)
        svm_proba = self.svm_classifier.predict_proba(resume_features)
        
        # Ensemble predictions with proper array handling
        ensemble_scores = np.mean([rf_proba, dt_proba, svm_proba], axis=0)
        
        # Combine all scores
        final_scores = []
        for idx in range(len(self.df)):
            row = self.df.iloc[idx]
            location_score = 1.0 if idx in location_indices else 0.0
            qual_score = float(ensemble_scores[0][self.encoded_quals[idx]])
            
            # Calculate skills similarity with proper array handling
            skills_vector = self.skills_vectorizer.transform([str(row['skills'])]).toarray()
            skills_score = float(np.dot(resume_skills_vector, skills_vector.T) / 
                               (np.linalg.norm(resume_skills_vector) * np.linalg.norm(skills_vector)))
            
            final_score = (location_score + qual_score + skills_score) / 3
            final_scores.append({
                'internship_id': int(idx),
                'company': row['company'],
                'role': row['role'],
                'location': row['location'],
                'match_score': float(final_score)
            })
        
        # Sort by match score
        final_scores.sort(key=lambda x: x['match_score'], reverse=True)
        return final_scores[:5]  # Return top 5 matches

def cosine_similarity(a, b):
    return np.dot(a, b.T) / (np.linalg.norm(a) * np.linalg.norm(b))