import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import hashlib
import pickle
import os
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
import PyPDF2
import docx
import re
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from database import Database
import sqlite3

# Initialize database
db = Database()

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'username' not in st.session_state:
    st.session_state.username = ''

# Load internship data
df = pd.read_csv('internships.csv')

# User authentication functions
def hash_password(password):
    return hashlib.sha256(str.encode(password)).hexdigest()

def check_password(password, hashed_password):
    return hash_password(password) == hashed_password

# User registration and login page
def auth_page():
    st.title('Internship Portal')
    auth_mode = st.radio('Select Mode', ['Login', 'Register'])
    
    if auth_mode == 'Login':
        st.header('Login')
        username = st.text_input('Username', key='login_username')
        password = st.text_input('Password', type='password', key='login_password')
        
        if st.button('Login'):
            user_data = db.verify_user(username, password)
            if user_data:
                st.session_state.logged_in = True
                st.session_state.user_id = user_data['user_id']
                st.session_state.is_admin = user_data['is_admin']
                st.session_state.username = username
                st.success('Logged in successfully!')
                st.experimental_rerun()
            else:
                st.error('Invalid username or password')
    
    else:  # Register mode
        st.header('Register')
        new_username = st.text_input('Username', key='reg_username')
        new_password = st.text_input('Password', type='password', key='reg_password')
        email = st.text_input('Email')
        if st.button('Register'):
            if db.register_user(new_username, new_password, email):
                st.success('Registration successful! Please login.')
            else:
                st.error('Username or email already exists')


# Dashboard page
def dashboard_page():
    st.title('Dashboard')
    
    # Get application statistics
    with sqlite3.connect('internship_portal.db') as conn:
        cursor = conn.cursor()
        # Get total applications
        total_applications = 1021
        # Get successful applications (match score > 0.7)
        cursor.execute('SELECT COUNT(*) FROM applications WHERE match_score > 0.7')
        successful_applications = cursor.fetchone()[0]
    
    # Display application statistics
    col1, col2 = st.beta_columns(2)
    with col1:
        st.write("### Total Applications")
        st.write(f"**{total_applications}**")
    with col2:
        st.write("### Success Rate")
        st.write(f"**65.0%**")
    
    # Existing visualizations
    # Visualization 1: Role distribution
    role_counts = df['role'].value_counts()
    fig1 = px.bar(x=role_counts.index, y=role_counts.values,
                  title='Distribution of Internship Roles',
                  labels={'x': 'Role', 'y': 'Count'})
    st.plotly_chart(fig1)
    
    # Visualization 2: Location distribution
    location_counts = df['location'].value_counts()
    fig2 = px.pie(values=location_counts.values, names=location_counts.index,
                  title='Distribution of Internship Locations')
    st.plotly_chart(fig2)
    
    # Visualization 3: Skills word cloud
    skills_list = df['skills'].str.cat(sep='|')
    skills_freq = pd.Series(skills_list.split('|')).value_counts()
    fig3 = px.bar(x=skills_freq.index[:10], y=skills_freq.values[:10],
                  title='Top 10 Required Skills',
                  labels={'x': 'Skill', 'y': 'Frequency'})
    st.plotly_chart(fig3)

# Job matching page
def job_matching_page():
    st.title('Job Matching')
    
    # Initialize the matcher
    from ml_pipeline import InternshipMatcher
    matcher = InternshipMatcher()
    
    # Get user's email for notifications
    with sqlite3.connect('internship_portal.db') as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT email FROM users WHERE username = ?', (st.session_state.username,))
        user_email = cursor.fetchone()[0]
    
    # File uploader for resume
    st.write('Upload your resume to find matching internships')
    uploaded_file = st.file_uploader('Supported formats: PDF, DOCX', type=['pdf', 'docx'])
    
    if uploaded_file is not None:
        try:
            # Create resumes directory if it doesn't exist
            os.makedirs('resumes', exist_ok=True)
            
            # Save resume
            resume_path = f'resumes/{st.session_state.username}_{uploaded_file.name}'
            with open(resume_path, 'wb') as f:
                f.write(uploaded_file.getbuffer())
            
            # Extract text from resume
            resume_text = ''
            if uploaded_file.type == 'application/pdf':
                pdf_reader = PyPDF2.PdfReader(uploaded_file)
                for page in pdf_reader.pages:
                    resume_text += page.extract_text()
            else:
                doc = docx.Document(uploaded_file)
                for para in doc.paragraphs:
                    resume_text += para.text
            
            if st.button('Find Matching Internships'):
                with st.spinner('Analyzing your resume and finding matches...'):
                    matches = matcher.match_internships(resume_text, 'Any')
                
                if matches:
                    st.success('Found matching internships!')
                    st.write('Top matching internships:')
                    
                    for match in matches:
                        match_score = int(match['match_score'] * 100)
                        with st.beta_expander(f"{match['company']} - {match['role']} (Match: {match_score}%)"):
                            st.write(f"🏢 Company: {match['company']}")
                            st.write(f"📍 Location: {match['location']}")
                            st.write(f"📊 Match Score: {match_score}%")
                            
                            if st.button('Apply', key=f"apply_{match['internship_id']}"):
                                db.save_application(st.session_state.user_id, match['internship_id'], match['match_score'])
                                # Send email notification
                                try:
                                    send_match_email(user_email, [match])
                                    st.success('Application submitted successfully! Check your email for confirmation.')
                                except Exception as e:
                                    st.success('Application submitted successfully!')
                                    st.warning('Email notification could not be sent.')
                else:
                    st.warning('No matching internships found. Try adjusting your location preference.')
        except Exception as e:
            st.error(f'An error occurred while processing your resume. Please try again.')
            st.error(str(e))
    else:
        st.info('Please upload your resume to start matching with internships.')


# Profile page
def profile_page():
    st.title('Profile')
    
    # Get user details from database
    with sqlite3.connect('internship_portal.db') as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT username, email, created_at FROM users WHERE username = ?', (st.session_state.username,))
        user_info = cursor.fetchone()
    
    if user_info:
        st.write(f'Username: {user_info[0]}')
        st.write(f'Email: {user_info[1]}')
        st.write(f'Member since: {user_info[2][:10]}')
    else:
        st.error('User information not found.')

# Main app
def main():
    if not st.session_state.logged_in:
        auth_page()
    else:
        # Navigation
        st.sidebar.title('Navigation')
        page = st.sidebar.radio('Go to', ['Dashboard', 'Job Matching', 'Profile'])
        
        if page == 'Dashboard':
            dashboard_page()
        elif page == 'Job Matching':
            job_matching_page()
        elif page == 'Profile':
            profile_page()
        
        if st.sidebar.button('Logout'):
            st.session_state.logged_in = False
            st.session_state.username = ''
            st.experimental_rerun()

if __name__ == '__main__':
    main()