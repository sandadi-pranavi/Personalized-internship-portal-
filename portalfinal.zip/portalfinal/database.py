import sqlite3
import hashlib
import os
from datetime import datetime

class Database:
    def __init__(self):
        self.db_file = 'internship_portal.db'
        self.init_database()
    
    def init_database(self):
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            
            # Create users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_admin BOOLEAN DEFAULT 0
                )
            ''')
            
            # Create user_profiles table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_profiles (
                    user_id INTEGER PRIMARY KEY,
                    full_name TEXT,
                    qualification TEXT,
                    skills TEXT,
                    preferred_location TEXT,
                    resume_path TEXT,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            ''')
            
            # Create applications table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS applications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    internship_id INTEGER,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    status TEXT DEFAULT 'pending',
                    match_score REAL,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            ''')
            
            # Create default admin user if not exists
            cursor.execute('SELECT * FROM users WHERE username = ?', ('admin',))
            if not cursor.fetchone():
                self.register_user('admin', 'admin', 'admin@example.com', is_admin=True)
            
            conn.commit()
    
    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register_user(self, username, password, email, is_admin=False):
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                hashed_password = self.hash_password(password)
                cursor.execute(
                    'INSERT INTO users (username, password, email, is_admin) VALUES (?, ?, ?, ?)',
                    (username, hashed_password, email, is_admin)
                )
                return True
        except sqlite3.IntegrityError:
            return False
    
    def verify_user(self, username, password):
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT id, password, is_admin FROM users WHERE username = ?',
                (username,)
            )
            result = cursor.fetchone()
            
            if result and result[1] == self.hash_password(password):
                return {'user_id': result[0], 'is_admin': result[2]}
            return None
    
    def update_profile(self, user_id, profile_data):
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO user_profiles 
                (user_id, full_name, qualification, skills, preferred_location, resume_path)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                user_id,
                profile_data.get('full_name'),
                profile_data.get('qualification'),
                profile_data.get('skills'),
                profile_data.get('preferred_location'),
                profile_data.get('resume_path')
            ))
    
    def get_profile(self, user_id):
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM user_profiles WHERE user_id = ?', (user_id,))
            result = cursor.fetchone()
            if result:
                return {
                    'full_name': result[1],
                    'qualification': result[2],
                    'skills': result[3],
                    'preferred_location': result[4],
                    'resume_path': result[5]
                }
            return None
    
    def save_application(self, user_id, internship_id, match_score):
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO applications (user_id, internship_id, match_score)
                VALUES (?, ?, ?)
            ''', (user_id, internship_id, match_score))
    
    def get_application_stats(self):
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT i.internship_role, COUNT(*) as count
                FROM applications a
                JOIN internships i ON a.internship_id = i.id
                GROUP BY i.internship_role
            ''')
            return cursor.fetchall()